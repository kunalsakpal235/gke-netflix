module.exports = { output: 'standalone' };
