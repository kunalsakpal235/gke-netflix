variable "project_id"    { type = string }
variable "region"        { type = string  default = "asia-south1" }
variable "registry_name" { type = string  default = "streaming-images" }
